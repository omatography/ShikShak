package com.example.ShikShak;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShikShakApplicationTests {

	@Test
	void contextLoads() {
	}

}
