package com.example.ShikShak;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShikShakApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShikShakApplication.class, args);
	}

}
